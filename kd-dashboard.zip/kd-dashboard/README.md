# KD Bank: Products Dashboard

One screen that shows savings, credit card, loan and wealth products in a unified list.

## Technology
- React 18 loaded from a CDN (no build step, no npm install)
- htm for JSX-like templates in plain JavaScript
- Plain CSS (responsive, sidebar turns into a top bar on mobile)
- Needs an internet connection the first time, to load React and fonts

## Run it
Needs Node.js (any recent version). No `npm install` required.

    node server.js      (or: npm start)

Open http://localhost:3000

`server.js` is a tiny mock API: `GET /api/products` returns the JSON in `products.json`, and it also serves the page files. (Opening `index.html` directly will not work because the browser blocks `fetch()` on `file://`.)

## Files
| File | Job |
|------|-----|
| `server.js` | Tiny mock API (`/api/products`) + static file server |
| `products.json` | Data only (what the mock API returns) |
| `app.js` | `fetchProducts()` data layer + React components (`App`, `Row`, `Details`) |
| `style.css` | Layout and theme |
| `index.html` | Page shell and script tags |

## Data vs UI
Components never hold product data. `App` calls `fetchProducts()` once and renders from state. For a real backend, point that one URL at your real endpoint.

## Features
- 9 products, 4 categories
- Each row: name, category, status, two key metrics, call-to-action (View details / Apply now)
- Category navigation with counts, search, status filter
- Details dialog (Esc to close), empty / loading / error states
- Summary counts calculated from the data
