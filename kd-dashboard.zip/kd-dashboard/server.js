// Tiny mock API + static file server. No npm packages needed (Node 14+).
// GET /api/products  -> returns products.json
// anything else      -> serves the files in this folder
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const TYPES = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.json': 'application/json' };

http.createServer((req, res) => {
  const url = req.url.split('?')[0];

  if (url === '/api/products') {
    fs.readFile(path.join(__dirname, 'products.json'), (err, data) => {
      if (err) { res.writeHead(500); return res.end('{"error":"cannot read products"}'); }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(data);
    });
    return;
  }

  const file = url === '/' ? 'index.html' : url.slice(1);
  const full = path.join(__dirname, path.normalize(file));
  if (!full.startsWith(__dirname)) { res.writeHead(403); return res.end(); }
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(full)] || 'text/plain' });
    res.end(data);
  });
}).listen(PORT, () => console.log('KD Bank running at http://localhost:' + PORT));
