/* React (loaded from CDN, no build step) + htm for JSX-like templates.
   Data comes only from products.json through fetchProducts(). */
const { useState, useEffect, useMemo } = React;
const html = htm.bind(React.createElement);

const CATS = ['Savings', 'Credit card', 'Loan', 'Wealth'];
const STATUSES = ['Active', 'Due soon', 'Overdue', 'Not opened'];
const ICON = { Savings: 'S', 'Credit card': 'C', Loan: 'L', Wealth: 'W' };

/* ---------- data layer ---------- */
function fetchProducts() {
  return fetch('/api/products').then(r => {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  });
}

/* ---------- small components ---------- */
function Row({ p, onView, onApply }) {
  const held = p.status !== 'Not opened';
  const tone = { Active: 'ok', 'Due soon': 'warn', Overdue: 'bad', 'Not opened': 'idle' }[p.status];
  return html`
    <li class=${'row cat-' + CATS.indexOf(p.category)}>
      <span class="badge" aria-hidden="true">${ICON[p.category]}</span>
      <div class="who">
        <h3>${p.name}</h3>
        <p>${p.category}</p>
      </div>
      <span class=${'status ' + tone}>${p.status}</span>
      <dl class="metrics">
        ${p.metrics.map(m => html`<div key=${m[0]}><dt>${m[0]}</dt><dd>${m[1]}</dd></div>`)}
      </dl>
      <button class=${held ? 'btn' : 'btn ghost'} onClick=${() => (held ? onView(p) : onApply(p))}>
        ${held ? 'View details' : 'Apply now'}
      </button>
    </li>`;
}

function Details({ p, onClose }) {
  useEffect(() => {
    const k = e => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', k);
    return () => document.removeEventListener('keydown', k);
  }, []);
  return html`
    <div class="scrim" onClick=${onClose}>
      <div class="modal" role="dialog" aria-modal="true" aria-label=${p.name} onClick=${e => e.stopPropagation()}>
        <h2>${p.name}</h2>
        <p class="muted">${p.category}, ${p.status}</p>
        <ul>${p.details.map(d => html`<li key=${d[0]}><span>${d[0]}</span><b>${d[1]}</b></li>`)}</ul>
        <button class="btn" autoFocus onClick=${onClose}>Close</button>
      </div>
    </div>`;
}

/* ---------- app ---------- */
function App() {
  const [all, setAll] = useState(null);
  const [error, setError] = useState(false);
  const [cat, setCat] = useState('All');
  const [status, setStatus] = useState('All');
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(null);
  const [note, setNote] = useState('');

  useEffect(() => { fetchProducts().then(setAll).catch(() => setError(true)); }, []);
  useEffect(() => { if (note) { const t = setTimeout(() => setNote(''), 2600); return () => clearTimeout(t); } }, [note]);

  const shown = useMemo(() => (all || []).filter(p =>
    (cat === 'All' || p.category === cat) &&
    (status === 'All' || p.status === status) &&
    (p.name + ' ' + p.category).toLowerCase().includes(q.trim().toLowerCase())), [all, cat, status, q]);

  const count = c => (all || []).filter(p => c === 'All' || p.category === c).length;
  const held = (all || []).filter(p => p.status !== 'Not opened').length;
  const attention = (all || []).filter(p => p.status === 'Due soon' || p.status === 'Overdue').length;

  return html`
    <div class="layout">
      <aside class="side">
        <div class="brand">KD Bank</div>
        <div class="summary">
          <div><b>${held}</b><span>products held</span></div>
          <div><b>${attention}</b><span>need attention</span></div>
        </div>
        <nav aria-label="Product category">
          ${['All', ...CATS].map(c => html`
            <button key=${c} class=${'nav' + (cat === c ? ' on' : '')} aria-pressed=${cat === c} onClick=${() => setCat(c)}>
              <span>${c === 'All' ? 'All products' : c}</span><small>${count(c)}</small>
            </button>`)}
        </nav>
        <label class="field">Status
          <select value=${status} onChange=${e => setStatus(e.target.value)}>
            ${['All', ...STATUSES].map(s => html`<option key=${s} value=${s}>${s === 'All' ? 'All statuses' : s}</option>`)}
          </select>
        </label>
      </aside>

      <main class="main">
        <header>
          <h1>Your products</h1>
          <input type="search" placeholder="Search by name or category" aria-label="Search products" value=${q} onInput=${e => setQ(e.target.value)} />
        </header>

        ${error && html`<p class="state">Could not load products.json. Run the folder with a local server (see README).</p>`}
        ${!all && !error && html`<p class="state">Loading your products…</p>`}
        ${all && !shown.length && html`<p class="state">No products match. Clear the search or pick another category.</p>`}
        <ul class="list">
          ${shown.map(p => html`<${Row} key=${p.id} p=${p} onView=${setOpen} onApply=${x => setNote('Application started for ' + x.name)} />`)}
        </ul>
      </main>

      ${open && html`<${Details} p=${open} onClose=${() => setOpen(null)} />`}
      ${note && html`<div class="toast" role="status">${note}</div>`}
    </div>`;
}

ReactDOM.createRoot(document.getElementById('root')).render(html`<${App} />`);
